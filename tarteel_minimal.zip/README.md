# Tarteel Mini — Minimal Flutter demo

Bu paket — **Tarteel** tipidagi ilovaning minimal, ishlaydigan nusxasi:
- Qur'on matnlarini (namuna) `assets/quran_sample.json` ichida saqlaydi.
- Oyatni tanlash, keyin mikrofon orqali o'qib, tanib olingan matnni original bilan taqqoslaydi.
- Speech-to-text uchun `speech_to_text` paketi ishlatilgan.

**Qanday ishlatish (PC yoki Android Studio tavsiya qilinadi):**
1. ZIPni oching va papkaga o'ting.
2. `flutter pub get` bajaring.
3. Qurilmangizni ulab `flutter run` buyrug'ini bajaring (yoki Android Studio'da Run tugmasi).
4. Agar Android manifestga ruxsat kerak bo'lsa, `AndroidManifest.xml` ga:
   `<uses-permission android:name="android.permission.RECORD_AUDIO"/>` qo'shing.

**Eslatma:** Agar telefoningizda Flutter o'rnatilmagan bo'lsa, ZIPni kompyuterga yuborib o'sha yerda ishga tushirishni tavsiya qilaman.
