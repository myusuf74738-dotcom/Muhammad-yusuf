
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:speech_to_text/speech_to_text.dart' as stt;

void main() {
  runApp(const TarteelMiniApp());
}

class TarteelMiniApp extends StatelessWidget {
  const TarteelMiniApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tarteel Mini',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const VerseListPage(),
    );
  }
}

class Verse {
  final int surah;
  final int ayah;
  final String text;
  Verse({required this.surah, required this.ayah, required this.text});
  factory Verse.fromJson(Map<String, dynamic> j) =>
      Verse(surah: j['surah'], ayah: j['ayah'], text: j['text']);
}

class VerseListPage extends StatefulWidget {
  const VerseListPage({super.key});

  @override
  State<VerseListPage> createState() => _VerseListPageState();
}

class _VerseListPageState extends State<VerseListPage> {
  List<Verse> _verses = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadVerses();
  }

  Future<void> _loadVerses() async {
    final raw = await rootBundle.loadString('assets/quran_sample.json');
    final List<dynamic> data = jsonDecode(raw);
    setState(() {
      _verses = data.map((e) => Verse.fromJson(e)).toList();
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tarteel Mini'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: _verses.length,
              itemBuilder: (context, index) {
                final v = _verses[index];
                return ListTile(
                  title: Text('Surah ${v.surah}:${v.ayah}'),
                  subtitle: Text(
                    v.text,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    textDirection: TextDirection.rtl,
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => VersePage(verse: v),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}

class VersePage extends StatefulWidget {
  final Verse verse;
  const VersePage({super.key, required this.verse});

  @override
  State<VersePage> createState() => _VersePageState();
}

class _VersePageState extends State<VersePage> {
  late stt.SpeechToText _speech;
  bool _available = false;
  bool _listening = false;
  String _recognized = '';

  @override
  void initState() {
    super.initState();
    _speech = stt.SpeechToText();
    _initSpeech();
  }

  Future<void> _initSpeech() async {
    try {
      _available = await _speech.initialize(
        onStatus: (status) {
          // debugPrint('Speech status: $status');
        },
        onError: (error) {
          // debugPrint('Speech error: $error');
        },
      );
      setState(() {});
    } catch (e) {
      // ignore
    }
  }

  void _startListening() async {
    if (!_available) {
      await _initSpeech();
    }
    if (_available) {
      setState(() {
        _listening = true;
        _recognized = '';
      });
      _speech.listen(
        onResult: (val) {
          setState(() {
            _recognized = val.recognizedWords;
          });
          if (val.finalResult) {
            _stopListening();
          }
        },
        listenFor: const Duration(seconds: 10),
        localeId: 'ar', // Arabic locale
        cancelOnError: true,
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Speech not available')));
    }
  }

  void _stopListening() {
    _speech.stop();
    setState(() {
      _listening = false;
    });
  }

  double _matchPercent(String original, String recognized) {
    String sanitize(String s) => s.replaceAll(RegExp(r'[^\u0600-\u06FF0-9A-Za-z\u0020]'), ' ').toLowerCase();
    final a = sanitize(original).split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    final b = sanitize(recognized).split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    if (a.isEmpty) return 0.0;
    final setA = a.toSet();
    final setB = b.toSet();
    final common = setA.intersection(setB).length;
    return (common / a.length) * 100;
  }

  @override
  Widget build(BuildContext context) {
    final orig = widget.verse.text;
    final percent = _recognized.isEmpty ? 0.0 : _matchPercent(orig, _recognized);
    return Scaffold(
      appBar: AppBar(
        title: Text('Surah ${widget.verse.surah}:${widget.verse.ayah}'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const Text('Original (oyat):', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(orig, style: const TextStyle(fontSize: 22), textDirection: TextDirection.rtl),
            const SizedBox(height: 24),
            const Text('Recognized (tanilgan):', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(_recognized.isEmpty ? '---' : _recognized),
            ),
            const SizedBox(height: 16),
            LinearProgressIndicator(value: percent/100),
            const SizedBox(height: 8),
            Text('Match: ${percent.toStringAsFixed(1)}%'),
            const Spacer(),
            Text(_listening ? 'Listening...' : 'Press mic to start', style: const TextStyle(fontStyle: FontStyle.italic)),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                FloatingActionButton(
                  heroTag: 'mic',
                  onPressed: _listening ? _stopListening : _startListening,
                  child: Icon(_listening ? Icons.stop : Icons.mic),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
